package puzzleandres;

/**
 *
 * @author CRISTIAN OVANDO
 */
public class PuzzleAndres {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       GraficoPuzzle abrir=new GraficoPuzzle();
       abrir.setVisible(true);
       abrir.setLocationRelativeTo(null);
       abrir.setResizable(false);
        
       
    }
    
}
